from django.contrib.gis.geos import \
    GEOSGeometry as Geometry, \
    GEOSException as GeometryException
