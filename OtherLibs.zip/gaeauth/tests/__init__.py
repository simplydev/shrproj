from gaeauth.tests.backends import *
from gaeauth.tests.middleware import *
from gaeauth.tests.models import *
from gaeauth.tests.views import *
